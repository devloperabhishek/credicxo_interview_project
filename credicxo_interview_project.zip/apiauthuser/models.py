from django.db import models

# Create your models here.

def upload_path(instance, filname):
    return '/'.join(['ProfilePicture', str(instance.user_name), filname])

class USERTABLE(models.Model):
    user_name = models.CharField(max_length=250,blank=True, null=True)
    password = models.CharField(max_length=250,blank=True, null=True)
    name = models.CharField(max_length=250,blank=True, null=True)
    role = models.CharField(max_length=250,blank=True, null=True)
    email = models.CharField(max_length=250,blank=True, null=True)
    

