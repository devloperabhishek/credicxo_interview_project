from django.apps import AppConfig


class ApiauthuserConfig(AppConfig):
    name = 'apiauthuser'
