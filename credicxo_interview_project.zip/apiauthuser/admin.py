from django.contrib import admin
from .models import USERTABLE

# Register your models here.

admin.site.register(USERTABLE)