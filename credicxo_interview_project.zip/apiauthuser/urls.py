from django.urls import include, path
from apiauthuser.views import UserViewSet, UserAddSet, UserLoginSet
from teacher_api.views import TeacherViewSet, StudentAddViewSet




urlpatterns = [
    path('api/login', UserLoginSet, name="logn user"),
    path('api/user-list/', UserViewSet, name="list all student and teacher"),
    path('api/user-add', UserAddSet, name=" add student and teacher"),
    path('api/teacher/', TeacherViewSet, name="list of teacher"),
    path('api/student-add/', StudentAddViewSet, name="Add Student View Set"),

   

]




