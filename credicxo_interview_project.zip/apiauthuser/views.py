from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response

from rest_framework.permissions import IsAuthenticated



from .models import USERTABLE
from datetime import datetime
from teacher_api.models import Teacher
from student_api.models import Student


permission_classes = (IsAuthenticated,)
# Create your views here.



# UserViewSet
@api_view(['GET'])
def UserViewSet(request):
    USERTABLE_GET = USERTABLE.objects.all().order_by('-id')
    tag = []
    for index in USERTABLE_GET:
        tag.append({
            'id': index.id,
            'user_name': index.user_name,
            'password': index.password,
            'name': index.name,
            'role': index.role,
            'email': index.email,
        })
    return Response(tag)

# UserAddSet
@api_view(['POST'])
def UserAddSet(request):
    USERTABLE_GET = USERTABLE.objects.filter(name= request.data.get('name'))
    if USERTABLE_GET:
        return Response('exist')
    else:
        USERTABLE_ADD = USERTABLE()
        USERTABLE_ADD.user_name = request.data.get('user_name')
        USERTABLE_ADD.password = request.data.get('password')
        USERTABLE_ADD.name = request.data.get('name')
        USERTABLE_ADD.email = request.data.get('email')
        USERTABLE_ADD.role = request.data.get('role')
        USERTABLE_ADD.save()

        if USERTABLE_ADD.role == "2":
            TEACHER_ADD = Teacher()
            TEACHER_ADD.user_id = USERTABLE_ADD.id
            TEACHER_ADD.name = request.data.get('name')
            TEACHER_ADD.save()

        if USERTABLE_ADD.role == "3":
            STUDENT_ADD = Student()
            STUDENT_ADD.user_id = USERTABLE_ADD.id
            STUDENT_ADD.name = request.data.get('name')
            STUDENT_ADD.roll = request.data.get('roll')
            STUDENT_ADD.classes = request.data.get('classes')
            STUDENT_ADD.save()
            
    return Response('success')


# login 
@api_view(['GET','POST'])
def UserLoginSet(request):
    if request.method == 'POST':

        # Checking returing query set
        UserAccountData = USERTABLE.objects.filter(user_name= request.data.get("user_name"), password= request.data.get("password"))
        if UserAccountData:
            # get data 
            UserAccountData = USERTABLE.objects.get(user_name= request.data.get("user_name"), password= request.data.get("password"))
            
            # Get current data
            now = datetime.now()
            current_time = now.strftime("%H:%M")

            if UserAccountData.role == '1':
                # return Response('admin')
                # Store tn a local json
                TEACHER_DATA = Student.objects.all().order_by('-id')
                tag_teacher = []
                for index in TEACHER_DATA:
                    tag_teacher.append({
                        'name' : index.name,
                    })

                STUDENT_DATA = Student.objects.all().order_by('-id')
                tag_student = []
                for index in STUDENT_DATA:
                    tag_student.append({
                        'name' : index.name,
                    })
                UserAccountDataResponse = {
                    'id': UserAccountData.id,
                    'user_name': UserAccountData.user_name,
                    'password': UserAccountData.password,
                    'name': UserAccountData.name,
                    'role': UserAccountData.role,
                    'email': UserAccountData.email,
                    'time': current_time,
                    'teacher_data': tag_teacher,
                    'student_data': tag_student
                }
                
                return Response(UserAccountDataResponse)
            elif UserAccountData.role == '2':
                DATA = Student.objects.all().order_by('-id')
                tag = []
                for index in DATA:
                    tag.append({
                        'name' : index.name,
                    })
                
                UserAccountDataResponse = {
                    'id': UserAccountData.id,
                    'user_name': UserAccountData.user_name,
                    'password': UserAccountData.password,
                    'name': UserAccountData.name,
                    'role': UserAccountData.role,
                    'email': UserAccountData.email,
                    'time': current_time,
                    'student_data': tag
                }
                
                return Response(UserAccountDataResponse)
                # return Response('teacher')
            elif UserAccountData.role == '3':
                STUDENT_Data = Student.objects.get(user_id= UserAccountData.id)
                UserAccountDataResponse = {
                    'id': UserAccountData.id,
                    'user_name': UserAccountData.user_name,
                    'password': UserAccountData.password,
                    'name': UserAccountData.name,
                    'role': UserAccountData.role,
                    'email': UserAccountData.email,
                    'time': current_time,
                    'student_data': {
                                   'name_of_student': STUDENT_Data.name,
                                   'roll': STUDENT_Data.roll,
                                   'class': STUDENT_Data.classes,
                              },
                }
                return Response(UserAccountDataResponse)
            else:
                return Response('error')

        else: 
            # for empty value
            UserAccountData = {
                'status': '400'
            }
        return Response(UserAccountData)
    else:
        UserSerializerData = [{
            'username': request.session.get('username'),
        }]
        return Response(UserSerializerData)