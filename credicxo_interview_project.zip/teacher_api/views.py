from django.shortcuts import render
from rest_framework import viewsets

from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import Teacher
from student_api.models import Student
from apiauthuser.models import USERTABLE

# Create your views here.



# teache all data
@api_view(['GET'])
def TeacherViewSet(request):
    DATA = Teacher.objects.all().order_by('-id')
    tag = []
    for index in DATA:
        tag.append({
            'id' : index.id,
            'name' : index.name,
        })
    return Response(tag)

# student add
@api_view(['POST'])
def StudentAddViewSet(request):
    CHECK = USERTABLE.objects.filter(user_name= request.data.get('user_name'))
    if CHECK:
        return Response('exist')
    else:
        USERTABLE_ADD = USERTABLE()
        USERTABLE_ADD.user_name = request.data.get('user_name')
        USERTABLE_ADD.password = request.data.get('password')
        USERTABLE_ADD.name = request.data.get('name')
        USERTABLE_ADD.sex = request.data.get('sex')
        USERTABLE_ADD.role = 3
        USERTABLE_ADD.save()

        STUDENT_ADD = Student()
        STUDENT_ADD.user_id = USERTABLE_ADD.id
        STUDENT_ADD.name = request.data.get('name')
        STUDENT_ADD.roll = request.data.get('roll')
        STUDENT_ADD.classes = request.data.get('classes')
        STUDENT_ADD.save()
        
    return Response('sucess')

