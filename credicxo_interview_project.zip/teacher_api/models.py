from django.db import models

# Create your models here.


from django.db import models


class Teacher(models.Model):
    user_id = models.CharField(max_length=60,blank=True, null=True)
    name = models.CharField(max_length=60)