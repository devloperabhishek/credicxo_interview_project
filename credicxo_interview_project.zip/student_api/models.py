from django.db import models

# Create your models here.


class Student(models.Model):
    user_id = models.CharField(max_length=60,blank=True, null=True)
    name = models.CharField(max_length=60)
    roll = models.CharField(max_length=60,blank=True, null=True)
    classes = models.CharField(max_length=60,blank=True, null=True)
